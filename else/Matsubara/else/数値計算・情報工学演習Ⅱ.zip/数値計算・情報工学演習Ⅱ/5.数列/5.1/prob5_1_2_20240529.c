#include<stdio.h>
#include<math.h>
#define N 5
double general_term(double a0,double a1,int i){
	double alpha = (1.0 + sqrt(5.0)) / 2.0;
	double beta = (1.0 - sqrt(5.0)) / 2.0;
	double ai = 1.0 / sqrt(5.0) * (pow(alpha,i) * (a1 - beta * a0) - pow(beta, i) * (a1 - alpha * a0));
	return ai;
}
int main(){
	double A[N];
	double Ar[N];
	int i;
	double a0 = 0.0, a1 = 1.0;
	double ai, aim1,aim2;
	printf("general terms without array\n");
	for(i = 0; i < N; i ++){
		ai = general_term(a0, a1, i);
		printf("a%d = %f\n", i,  ai);
	}
	printf("-----------------------------\n");
	printf("general terms with array\n");
	for(i = 0; i < N; i ++){
		A[i] = general_term(a0, a1, i);
		printf("A[%d] = %f\n", i,  A[i]);
	}
	printf("-----------------------------\n");
	printf("recurrence relation with array\n");
	Ar[0] = a0;
	Ar[1] = a1;
	printf("Ar[%d] = %f\n", 0,  Ar[0]);
	printf("Ar[%d] = %f\n", 1,  Ar[1]);
	for(i = 2; i < N; i ++){
		Ar[i] = Ar[i-1] + Ar[i-2];
		printf("Ar[%d] = %f\n",i,Ar[i]);
	}
	printf("-----------------------------\n");
	printf("recurrence relation without array\n");
	aim2 = a0;
	aim1 = a1;
	printf("A[%d] = %f\n",0,aim2);
	printf("A[%d] = %f\n",1,aim1);
	for(i = 2; i < N; i ++){
		ai = aim1 + aim2;
		printf("a%d = %f\n", i,  ai);
		aim2 = aim1;
		aim1 = ai;
	}
	return 0;
}	
