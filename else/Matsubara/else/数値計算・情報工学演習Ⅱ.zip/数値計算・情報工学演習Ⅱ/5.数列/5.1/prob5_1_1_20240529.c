#include<stdio.h>
#define N 5
int main(){
	double A[N];
	double Ar[N];
	int i;
	double a = 1.0, d = 0.5;
	double ai, aim1;
	printf("general terms without array\n");
	for(i = 0; i < N; i ++){
		ai = a + i * d;
		printf("a%d = %f\n", i,  ai);
	}
	printf("-----------------------------\n");
	printf("general terms with array\n");
	for(i = 0; i < N; i ++){
		A[i] = a + i * d;
		printf("A[%d] = %f\n", i,  A[i]);
	}
	printf("-----------------------------\n");
	printf("recurrence relation with array\n");
	Ar[0] = a;
	printf("Ar[%d] = %f\n", 0,  Ar[0]);
	for(i = 1; i < N; i ++){
		Ar[i] = Ar[i-1] + d;
		printf("Ar[%d] = %f\n",i,Ar[i]);
	}
	printf("-----------------------------\n");
	printf("recurrence relation without array\n");
	aim1 = a;
	printf("a%d = %f\n",0,aim1);
	for(i = 1; i < N; i ++){
		ai = aim1 + d;
		printf("a%d = %f\n", i,  ai);
		aim1 = ai;
	}
	return 0;
}	
