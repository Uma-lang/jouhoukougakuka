#include<stdio.h>
#include<math.h>
#define N 5
double general_term(double a0,double a1, double a2, int i){
	double alpha = 1.0 - sqrt(5.0);
	double beta = 1.0 + sqrt(5.0);
	double c1 = (beta * a0 - (1.0 + beta) * a1 + a2) / 10.0;
	double c2 = (alpha * a0 - (1.0 + alpha) * a1 + a2) / 10.0;
	double c3 = (4.0 * a0 + 2.0 * a1 - a2) / 5.0;
	double ai = pow(alpha, i) * c1 + pow(beta, i) * c2 + c3;
	return ai;
}
int main(){
	double A[N];
	double Ar[N];
	int i;
	double a0 = 0.0, a1 = 1.0, a2 = 2.0;
	double ai, aim1, aim2, aim3;
	printf("general terms without array\n");
	for(i = 0; i < N; i ++){
		ai = general_term(a0, a1, a2, i);
		printf("a%d = %f\n", i,  ai);
	}
	printf("-----------------------------\n");
	printf("general terms with array\n");
	for(i = 0; i < N; i ++){
		A[i] = general_term(a0, a1, a2, i);
		printf("A[%d] = %f\n", i,  A[i]);
	}
	printf("-----------------------------\n");
	printf("recurrence relation with array\n");
	Ar[0] = a0;
	Ar[1] = a1;
	Ar[2] = a2;
	printf("Ar[%d] = %f\n", 0,  Ar[0]);
	printf("Ar[%d] = %f\n", 1,  Ar[1]);
	printf("Ar[%d] = %f\n", 2,  Ar[2]);
	for(i = 3; i < N; i ++){
		Ar[i] = 3.0 * Ar[i-1] + 2.0 * Ar[i-2] - 4.0 * Ar[i-3];
		printf("Ar[%d] = %f\n",i,Ar[i]);
	}
	printf("-----------------------------\n");
	printf("recurrence relation without array\n");
	aim3 = a0;
	aim2 = a1;
	aim1 = a2;
	printf("A[%d] = %f\n",0,aim3);
	printf("A[%d] = %f\n",1,aim2);
	printf("A[%d] = %f\n",2,aim1);
	for(i = 3; i < N; i ++){
		ai = 3.0 * aim1 + 2.0 * aim2 -4.0 * aim3;
		printf("a%d = %f\n", i,  ai);
		aim3 = aim2; 
		aim2 = aim1;
		aim1 = ai;
	}
	return 0;
}	
