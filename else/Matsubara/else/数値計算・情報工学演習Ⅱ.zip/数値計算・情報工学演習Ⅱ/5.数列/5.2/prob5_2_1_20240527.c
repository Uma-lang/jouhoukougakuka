#include<stdio.h>
#include<math.h>
int main(){
	int i,maxi = 10000;
	double a0 = 0.0;
	double ai, aim1;
	double eps = 1e-8;
	FILE *fp;
	
	fp = fopen("output.csv","w");
	
	fprintf(fp, "i,ai / n");
	
	aim1 = a0;
	printf("a%d = %f\n", 0, aim1);
	fprintf(fp, "%d, %f\n",0, aim1);
	for(i = 1; i < maxi; i ++){
		ai = 2.0 / 3.0 * aim1 + 1;
		printf("i = %d, ai = %f\n", i,ai);
		fprintf(fp, "%d,%f\n", i, ai);
		if(fabs(ai - aim1) < eps){
			break;
		}
		aim1 = ai;
	}
	fclose(fp);
	return 0;
}