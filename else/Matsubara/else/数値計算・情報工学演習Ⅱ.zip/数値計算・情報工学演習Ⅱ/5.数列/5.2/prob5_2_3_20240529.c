#include<stdio.h>
#include<math.h>
#define N 5
double general_term(double a0,double a1, double a2, int i){
	double alpha = 1.0 - sqrt(5.0);
	double beta = 1.0 + sqrt(5.0);
	double c1 = (beta * a0 - (1.0 + beta) * a1 + a2) / 10.0;
	double c2 = (alpha * a0 - (1.0 + alpha) * a1 + a2) / 10.0;
	double c3 = (4.0 * a0 + 2.0 * a1 - a2) / 5.0;
	double ai = pow(alpha, i) * c1 + pow(beta, i) * c2 + c3;
	return ai;
}

int main(){
	int i, maxi = 10000;
	double a0 = 0.0, a1 = 1.0, a2 = 2.0;
	double ai, aim1, aim2, aim3;
	double bi, bim1, bi_formula;
	double true_value = 1.0 + sqrt(5);
	double eps = 1e-8;
	FILE *fp;

	fp = fopen("output5_2_3.csv","w");
	fprintf(fp, "i,bi\n");
	aim3 = a0;
	aim2 = a1;
	aim1 = a2;
	bim1 = (a2 -a1) / (a1 - a0);
	bi_formula = general_term(a0, a1, a2, 2);
	printf("i = %d, bi= %f, bi(formula) = %f\n",2 ,bim1, bi_formula);
	for(i = 3; i < maxi; i ++){
		ai = 3.0 * aim1 + 2.0 * aim2 - 4.0 * aim3;
		bi = (ai - aim1) / (aim1 - aim2);
		bi_formula = general_term(a0, a1, a2, i);
		printf("i = %d, bi = %f, bi(formula) = %f\n", i, bi, bi_formula);
		fprintf(fp, "%d,%f\n", i, bi);
		if(fabs(bi - bim1) < eps){
			break;
		}
		aim3 = aim2;
		aim2 = aim1;
		aim1 = ai;
		bim1 = bi;
	}
	printf("limit(true value) = %f\n", true_value);
	return 0;
}	
