#include<stdio.h>
#include<math.h>
#include<time.h>
double f(double x){
	return 1.0 / (x * x + 1.0);
}
double trapezoidal(double a, double b,int n){	//n=2^m
	int i, k;
	double x;
	double s1, sm, smp1;
	double hm, hmp1;
	double sum = 0.0;
	double eps = 1e-8;
	s1 = f((a + b) / 2.0);
	sm = s1;
	for(i = 0; i < n; i++){
		sum = 0.0;
		hm = (b - a) / n;
		hmp1 = (b - a) / n / 2.0;
		for(k = 0; k < n; k++){
			x = 2.0 * k + 1.0;
			sum += f(a + x * hmp1);
		}
		smp1 = sm + sum;
		sm = smp1;
		if(fabs(sm - smp1) < eps) break;
	}
	return hm / 2.0 * (f(a) + 2.0 * sm + f(b));
}
int main(){
	clock_t start_clock, end_clock;
	double time_for;
	int i, n, nn, m, k;
	nn = 100000;
	start_clock = clock();
	double N = 1e20;
	double a = 0.0, b = 1.0;
	double Jm_trap, Jmm1_trap;
	double eps = 1e-8;
	FILE *fp;
	fp = fopen("output5_3_add_trap.csv","w");
	Jmm1_trap = trapezoidal(a, b, 1);
	printf("m = %d, ,n = %d, Jm(tap) = %lf\n", 1, 2, Jmm1_trap);
	fprintf(fp, "%d,%f\n", 1, Jmm1_trap);
	for(m = 2; m < N; m++){
		n = 1;
		for(i = 0; i < m; i++){
			n *= 2;
		}
		Jm_trap = trapezoidal(a, b, n);
		printf("m = %d, n = %d, Jm(trap) = %lf\n", m, n, Jm_trap);
		fprintf(fp, "%d,%f\n", n, Jm_trap);
		if(fabs(Jm_trap - Jmm1_trap) < eps) break;
		Jmm1_trap = Jm_trap;
	}
	fclose(fp);
	end_clock = clock();
	time_for = (double)(end_clock - start_clock) / CLOCKS_PER_SEC;
	printf("n = %d, time_for = %e\n", nn, time_for);
	return 0;
}
