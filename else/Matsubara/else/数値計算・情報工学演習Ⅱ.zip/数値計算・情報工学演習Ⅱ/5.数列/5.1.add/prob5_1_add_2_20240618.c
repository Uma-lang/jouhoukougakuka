#include<stdio.h>
#include<math.h>
#define N 5
double general_term(double a0, double a1, int i){
	double ai, beta, ganma;
	beta = (1.0 - sqrt(7.0)) / 6.0;
	ganma = (1.0 + sqrt(7.0)) / 6.0;
	ai = 2.0 + (2.0 * sqrt(7.0) / 7.0 - 1.0) * pow(beta, i) - (2.0 * sqrt(7.0) / 7.0 + 1.0) * pow(ganma, i);
	return ai;
}
int main(){
	int i, maxi = 10000;
	double a0 = 0.0, a1 = 1.0;
	double ai, aim1, aim2, ai_formula;
	double eps = 1e-9;
	double L = 1e20;
	FILE *fp;
	fp = fopen("output5_1_add_2.csv","w");
	fprintf(fp, "i,ai\n");
	aim1 = a1;
	aim2 = a0;
	ai_formula = general_term(a0, a1, 0);
	printf("i = %d, a%d = %f, ai(formula) = %f\n",0,0,aim1, ai_formula);
	for(i = 1; i < maxi; i++){
		ai = 1.0 / 3.0 * aim1 + 1.0 / 6.0 * aim2 + 1.0;
		ai_formula = general_term(a0, a1, i);
		printf("i = %d, ai = %f, ai(formula) = %f\n", i, ai, ai_formula);
		fprintf(fp, "%d,%f\n", i, ai);
		if(fabs(ai - aim1) < eps){
			break;
		}
		else if(ai > L){
			printf("infinity");
			break;
		}
		else if(ai < -L){
			printf("-infinity");
			break;
		}
		aim1 = ai;
		aim2 = aim1;
	}
	fclose(fp);
	return 0;
	
}
