#include<stdio.h>
#include<math.h>
#define N 5
int main(){
	int i, maxi = 10000;
	double a0 = -1.0;
	double ai, aim1, ai_formula;
	double eps = 1e-9;
	double L = 1e20;
	FILE *fp;
	fp = fopen("output5_1_add_a0=-1.csv","w");
	fprintf(fp, "i,ai\n");
	aim1 = a0;
	printf("i = %d, a%d = %f\n",0,0,aim1);
	for(i = 1; i < maxi; i++){
		ai = 2.0 * aim1 - 1;
		printf("i = %d, ai = %f\n", i, ai);
		fprintf(fp, "%d,%f\n", i, ai);
		if(fabs(ai - aim1) < eps){
			break;
		}
		else if(ai > L){
			printf("infinity");
			break;
		}
		else if(ai < -L){
			printf("-infinity");
			break;
		}
		aim1 = ai;
	}
	fclose(fp);
	return 0;
	
}
