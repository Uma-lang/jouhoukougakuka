#include<stdio.h>
#include<math.h>
double f(double x){
	return 1.0 / (x * x + 1.0);
}
double first_Simpson(double a, double b, int n){
	double h = (b - a) / 2.0 / n;
	double sum_2i0 = 0.0, sum_2i1 = 0.0;
	int i;
	for(i = 1; i < n; i++){
		sum_2i0 += f(a + h * i * 2.0);
	}
	for(i = 0; i < n; i++){
		sum_2i1 += f(a + h * (i * 2.0 + 1.0));
	}
	return h / 3.0 * (f(a) + 2.0 * sum_2i0 + 4.0 * sum_2i1 + f(b));
}
int main(){
	int n, N = 1e9;
	double a = 0.0, b = 1.0;
	double I_1simp_n, I_1simp_n1;
	double eps = 1e-9;
	FILE *fp;
	printf("eps = %.e\n", eps);
	fp = fopen("output5_2_add_1simp.csv","w");
	I_1simp_n1 = first_Simpson(a,b,1);
	//printf("n = %d, Ini(1simp) = %f\n", 1, I_1simp_n1);
	fprintf(fp, "%d,%f\n", 1, I_1simp_n1);
	for(n = 2; n <= N; n++){
		I_1simp_n = first_Simpson(a,b,n);
		//printf("n = %d, Ini(1simp) = %f\n", n, I_1simp_n);
		fprintf(fp, "%d,%f\n", n, I_1simp_n);
		if(fabs(I_1simp_n - I_1simp_n1) < eps){
			printf("n = %d, Ini(1simp) = %f\n", n, I_1simp_n);
			break;
		}
		I_1simp_n1 = I_1simp_n;
	}
	return 0;
}
