#include<stdio.h>
#include<math.h>
#include<time.h>
double f(double x){
	return  1.0 / (x * x + 1.0);
}
double trapezoidal(double a, double b,int n){
	int i;
	double h = (b - a) / n;
	double sum = 0.0;
	for(i = 1; i < n; i++){
		sum += f(a + h * i);
	}
	return h / 2.0 * (f(a) + 2.0 * sum + f(b));
}
int main(){
	//clock_t start_clock, end_clock;
	//double time_for;
	//start_clock = clock();
	int n, N = 1e9;
	double eps = 1e-9;
	double a = 0.0, b = 1.0;
	double In_trap, Inm1_trap;
	FILE *fp;
	printf("eps = %.e\n", eps);
	fp = fopen("output5_2_add_trap.csv","w");
	//Inm1_trap = trapezoidal(a,b,1);
	//printf("n = %d, Ini(trap) = %f\n", 1, Inm1_trap);
	fprintf(fp, "%d,%f\n", 1, Inm1_trap);
	for(n = 2; n < N; n++){
		In_trap = trapezoidal(a,b,n);
		//printf("n = %d, Ini(trap) = %f\n", n, In_trap);
		fprintf(fp, "%d,%f\n", n, In_trap);
		if(fabs(In_trap - Inm1_trap) < eps){
			printf("n = %d, Ini(trap) = %f\n", n, In_trap);
			break;
		}
		Inm1_trap = In_trap;
	}
	//end_clock = clock();
	//time_for = (double)(end_clock - start_clock) / CLOCKS_PER_SEC;
	//printf("time for = %e\n", time_for);
	return 0;
}
