#include<stdio.h>
#include<math.h>
double f(double x){
	return 1.0 / (x * x + 1.0);
}
double second_Simpson(double a, double b,int n){
	double h = (b - a) / 3.0 / n;
	double sum_3i0 = 0.0, sum_3i1 = 0.0, sum_3i2 = 0.0;
	int i;
	for(i = 1; i < n; i++){
		sum_3i0 += f(a + h * 3.0 * i);
	}
	for(i = 0; i < n; i++){
		sum_3i1 += f(a + h * (3.0 * i + 1.0));
	}
	for(i = 0; i < n; i++){
		sum_3i2 += f(a + h * (3.0 * i + 2.0));
	}
	return 3.0 * h / 8.0 * (f(a) + 2.0 * sum_3i0 + 3.0 * sum_3i1 + 3.0 * sum_3i2 + f(b));
}



int main(){
	int n;
	double N = 1e20, eps = 1e-10;
	double a = 0.0, b = 1.0;
	double I_2simp_n, I_2simp_n1;
	FILE *fp;
	fp = fopen("output5_2_add_2simp.csv","w");
	I_2simp_n1 = second_Simpson(a,b,1);
	//printf("n = %d, Ini(2simp) = %f\n", 1, I_2simp_n1);
	fprintf(fp, "%d,%f\n", 1, I_2simp_n1);
	for(n = 2; n < N; n++){
		I_2simp_n = second_Simpson(a,b,n);
		//printf("n = %d, Ini(2simp) = %f\n", n, I_2simp_n);
		fprintf(fp, "%d,%f\n", n, I_2simp_n);
		if(fabs(I_2simp_n - I_2simp_n1) < eps){
			printf("n = %d, Ini(2simp) = %f\n", n, I_2simp_n);
			break;
		}
		I_2simp_n1 = I_2simp_n;
	}
	return 0;
}
