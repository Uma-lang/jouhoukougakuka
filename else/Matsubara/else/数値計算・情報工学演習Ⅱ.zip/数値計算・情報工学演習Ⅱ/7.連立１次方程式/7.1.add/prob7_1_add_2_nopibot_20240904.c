#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#define N 4
int main(){
	int i, j, k, n, max_row;
	double sum, max_val, tmp_a, tmp_b;
	//not pibot
	double _A[N][N] = {
		{2.0, 4.0, -2.0, 1.0},
		{1.0, 2.0, 1.0, 1.0},
		{1.0, 3.0, 2.0, 1.0},
		{1.0, 1.0, 1.0, 1.0}
		};
	double _B[N] = {8.0, 12.0, 17.0, 10.0};
	double _X[N];
	printf("not using pivot\n");
	for(k = 0; k < N - 1; k++){
		for(i = k + 1; i < N; i++){
			for(j = k + 1; j < N; j++){
				_A[i][j] -= _A[i][k] * _A[k][j] / _A[k][k];	//7.4.2
			}
			_B[i] -= _A[i][k] * _B[k] / _A[k][k];	//7.4.2
		}
	}
	for(i = 0; i < N; i++){
		for(j = 0; j < N; j++){
			printf("a%d%d = %lf, ", i + 1, j + 1, _A[i][j]);
		}
		printf("b%d = %lf\n", i, _B[i]);
	}
	_X[N - 1] = _B[N - 1] / _A[N - 1][N - 1];
	for(k = N - 2; k >= 0; k--){
		sum = 0.0;
		for(j = k + 1; j < N; j++){
			sum += _A[k][j] * _X[j];
		}
		_X[k] = (_B[k] - sum) / _A[k][k];
		
	}
	for(i = 0; i < N; i++){
		printf("X%d = %lf\n",i + 1, _X[i]);
	}
	return 0;
}
