#include<stdio.h>
#include<math.h>
#define N 4
int main(){
	int i, j, k, n, max_row;
	float sum, max_val, tmp_a, tmp_b;
	float X[N];
	float A[N][N] = {
		{2.0, 4.0, -2.0, 1.0},
		{1.0, 2.001, 1.002, 1.001},
		{1.0, 3.0, 2.0, 1.0},
		{1.0, 1.0, 1.0, 1.0}
		};
	float B[N] = {8.0, 12.012, 17.0, 10.0};
	printf("using pibot\n");
	for(k = 0; k < N - 1; k++){
		max_row = k;
		max_val = fabs(A[k][k]);
		for(i = k + 1; i < N; i++){
			if(fabs(A[i][k]) > max_val){
				max_row = i;
				max_val = fabs(A[i][k]);
			}
		}
		if(max_row != k){
			for(j = k; j < N; j++){
				tmp_a = A[k][j];
				A[k][j] = A[max_row][j];
				A[max_row][j] = tmp_a;
			}
			tmp_b = B[k];
			B[k] = B[max_row];
			B[max_row] = tmp_b;
		}
		for(i = k + 1; i < N; i++){
			for(j = k + 1; j < N; j++){
				A[i][j] -= A[i][k] * A[k][j] / A[k][k];	//7.4.2
			}
			B[i] -= A[i][k] * B[k] / A[k][k];	//7.4.2
		}
	}
	for(i = 0; i < N; i++){
		for(j = 0; j < N; j++){
			printf("a%d%d = %e, ", i + 1, j + 1, A[i][j]);
		}
		printf("b%d = %e\n", i, B[i]);
	}
	X[N - 1] = B[N - 1] / A[N - 1][N - 1];
	for(k = N - 2; k >= 0; k--){
		sum = 0.0;
		for(j = k + 1; j < N; j++){
			sum += A[k][j] * X[j];
		}
		X[k] = (B[k] - sum) / A[k][k];
		
	}
	for(i = 0; i < N; i++){
		printf("X%d = %e\n",i + 1, X[i]);
	}
	return 0;
}
