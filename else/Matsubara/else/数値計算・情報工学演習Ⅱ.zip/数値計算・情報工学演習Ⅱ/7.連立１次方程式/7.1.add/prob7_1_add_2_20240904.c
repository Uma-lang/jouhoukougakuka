#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#define N 4
int main(){
	int i, j, k, n, max_row;
	double sum, max_val, tmp_a, tmp_b;
	double X[N];
	double A[N][N] = {
		{2.0, 4.0, -2.0, 1.0},
		{1.0, 2.0, 1.0, 1.0},
		{1.0, 3.0, 2.0, 1.0},
		{1.0, 1.0, 1.0, 1.0}
		};
	double B[N] = {8.0, 12.0, 17.0, 10.0};
	printf("using pivot\n");
	for(k = 0; k < N - 1; k++){
		max_row = k;
		max_val = fabs(A[k][k]);
		for(i = k + 1; i < N; i++){
			if(fabs(A[i][k]) > max_val){
				max_row = i;
				max_val = fabs(A[i][k]);
			}
		}
		if(max_row != k){
			for(j = k; j < N; j++){
				tmp_a = A[k][j];
				A[k][j] = A[max_row][j];
				A[max_row][j] = tmp_a;
			}
			tmp_b = B[k];
			B[k] = B[max_row];
			B[max_row] = tmp_b;
		}
		for(i = k + 1; i < N; i++){
			for(j = k + 1; j < N; j++){
				A[i][j] -= A[i][k] * A[k][j] / A[k][k];	//7.4.2
			}
			B[i] -= A[i][k] * B[k] / A[k][k];	//7.4.2
		}
	}
	for(i = 0; i < N; i++){
		for(j = 0; j < N; j++){
			printf("a%d%d = %lf, ", i + 1, j + 1, A[i][j]);
		}
		printf("b%d = %lf\n", i, B[i]);
	}
	X[N - 1] = B[N - 1] / A[N - 1][N - 1];
	for(k = N - 2; k >= 0; k--){
		sum = 0.0;
		for(j = k + 1; j < N; j++){
			sum += A[k][j] * X[j];
		}
		X[k] = (B[k] - sum) / A[k][k];
		
	}
	for(i = 0; i < N; i++){
		printf("X%d = %lf\n",i + 1, X[i]);
	}
	//not pibot
	double _A[N][N] = {
		{2.0, 4.0, -2.0, 1.0},
		{1.0, 2.0, 1.0, 1.0},
		{1.0, 3.0, 2.0, 1.0},
		{1.0, 1.0, 1.0, 1.0}
		};
	double _B[N] = {8.0, 12.0, 17.0, 10.0};
	double _X[N];
	printf("\n------------------------------------------------------------------------------------\n\n");
	printf("not using pivot\n");
	for(k = 0; k < N - 1; k++){
		for(i = k + 1; i < N; i++){
			for(j = k + 1; j < N; j++){
				_A[i][j] -= _A[i][k] * _A[k][j] / _A[k][k];	//7.4.2
			}
			_B[i] -= _A[i][k] * _B[k] / _A[k][k];	//7.4.2
		}
	}
	for(i = 0; i < N; i++){
		for(j = 0; j < N; j++){
			printf("a%d%d = %lf, ", i + 1, j + 1, _A[i][j]);
		}
		printf("b%d = %lf\n", i, _B[i]);
	}
	_X[N - 1] = _B[N - 1] / _A[N - 1][N - 1];
	for(k = N - 2; k >= 0; k--){
		sum = 0.0;
		for(j = k + 1; j < N; j++){
			sum += _A[k][j] * _X[j];
		}
		_X[k] = (_B[k] - sum) / _A[k][k];
		
	}
	for(i = 0; i < N; i++){
		printf("X%d = %lf\n",i + 1, X[i]);
	}
	return 0;
}
