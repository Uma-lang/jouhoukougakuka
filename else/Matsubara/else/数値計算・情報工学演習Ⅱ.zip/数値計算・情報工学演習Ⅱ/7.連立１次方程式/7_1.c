#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#define N 4
int main(){
	int i, j, k, n = N;
	double sum;
	double X[N];
	double A[N][N] = {
		{4.0, 3.0, 2.0, 1.0},
		{2.0, 5.0, -3.0, -2.0},
		{1.0, -4.0, 8.0, -1.0},
		{-3.0, 2.0, -4.0, 5.0}
		};
	double B[N] = {20.0, -5.0, 13.0, 9.0};
	for(k = 0; k < n - 1; k++){
		for(i = k + 1 ; i < n; i++){
			for(j = k + 1; j < n; j++){
				A[i][j] -= A[i][k] * A[k][j] / A[k][k];
			}
			B[i] -= A[i][k] * B[k] / A[k][k];
		}
	}
	for(i = 0; i < N; i++){
		for(j = 0; j < N; j++){
			if(i > j){	
				printf("a%d%d = %lf, ", i + 1, j + 1, 0.0);
			}
			else{
				printf("a%d%d = %lf, ", i + 1, j + 1, A[i][j]);
			}
		}
		printf("b%d = %lf\n", i, B[i]);
	}
	X[n - 1] = B[n - 1] / A[n - 1][n - 1];
	for(k = n - 2; k >= 0; k--){
		sum = 0.0;
		for(j = k + 1; j < n; j++){
			sum += A[k][j] * X[j];
		}
		X[k] = (B[k] - sum) / A[k][k];
		
	}
	for(i = 0; i < N; i++){
		printf("X%d = %lf\n",i + 1, X[i]);
	}
	return 0;
}
