#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#define N 4
int main(){
	int i, j, k;
	double sum_i, sum_n, sum_x = 0.0;
	double eps = 1e-8, max = 1e+20;
	double X[N] = {0}, X1[N] = {0};
	double A[N][N] = {
		{4.0, 3.0, 2.0, 1.0},
		{2.0, 5.0, -3.0, -2.0},
		{1.0, -4.0, 8.0, -1.0},
		{-3.0, 2.0, -4.0, 5.0}
		};
	double B[N] = {20.0, -5.0, 13.0, 9.0};
	for(k = 0; k < max; k++){
		sum_x = 0.0;
		for(i = 0; i < N; i++){
			sum_i = 0.0;
			for(j = 0; j < i; j++){
				sum_i += A[i][j] * X1[j];
			}
			sum_n = 0.0;
			for(j = i + 1; j < N; j++){
				sum_n += A[i][j] * X[j];
			}
			X1[i] = (B[i] - sum_i - sum_n) / A[i][i];
			sum_x += fabs(X1[i] - X[i]);
		}
		if(sum_x < eps){
			for(i = 0; i < N; i++){
				X[i] = X1[i];
			}
			break;
		}
		for(i = 0; i < N; i++){
			X[i] = X1[i];
		}
	}
	printf("Gauss-Seidel method\n");
	for(i = 0; i < N; i++){
		printf("X[%d] = %.10e\n",i, X[i]);
	}
	printf("iterarion = %d\n", k);
	return 0;
}
