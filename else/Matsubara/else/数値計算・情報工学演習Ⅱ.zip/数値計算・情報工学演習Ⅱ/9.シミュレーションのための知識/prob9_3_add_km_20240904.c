#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<math.h>
int main(){
	srand(time(NULL));
	int i, j, N = 10000, n = 30;
	double K, U, V, X;
	double output;
	double low, high;
	int kinder_monahan[n];
	int bunpu[n];
	for(i = 0; i < n; i++) kinder_monahan[i] = 0;
	K = sqrt(M_PI / 2.0);
	for(i = 0; i < N; i++){
		while(1){
			U = (double)(rand() + 1.0) / (RAND_MAX + 1.0);
			V = (double)(rand() + 1.0) / (RAND_MAX + 1.0);
			if(V * V / U / U <= -4.0 * log(U)) break;
		}
		X = V / U;
		if((int)(2.0 * drand48()) % 2 == 0) output = X;
		else output = -X;
		for(j = 0; j < n; j++){
			low = -3.0 + 0.2 * j;
			high = low + 0.2;
			if(low < output && output < high){ 
				kinder_monahan[j]++;
				break;
			}
		}
	}
	for(i = 0; i < n; i++) bunpu[i] = kinder_monahan[i] / 20;
	for(i = 0; i < n; i++){
		for(j = 0; j < bunpu[i]; j++) printf("*");
		printf("\n");
	}
	return 0;
}
