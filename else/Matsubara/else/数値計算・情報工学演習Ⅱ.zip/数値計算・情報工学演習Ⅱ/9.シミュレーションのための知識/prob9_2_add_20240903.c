#include<stdio.h>
#include<stdlib.h>
#include<time.h>
double f(double x){
	return x * x;
}
int main(){
	srand(time(NULL));
	int i, j, n, N = 1;
	double rand_x, rand_y, ratio, square, true_val = 1.0 / 3.0;
	for(i = 0; i < 5; i++){
		N *= 10;
		n = 0;
		for(j = 0; j < N; j++){
			rand_x = (double)rand() / RAND_MAX;
			rand_y = (double)rand() / RAND_MAX;
			if(f(rand_x) > rand_y) n++;
		}
		ratio = (double)n / N;
		square = ratio * 1.0;
		printf("N = %d, ratio = %f, true value = %f\n", N, square, true_val);
	}
	return 0;
}
