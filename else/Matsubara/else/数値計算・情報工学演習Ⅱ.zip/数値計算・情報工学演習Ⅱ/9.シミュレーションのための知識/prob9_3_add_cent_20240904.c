#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<math.h>
int main(){
	srand(time(NULL));
	int i, j, k, n = 6, _n = 30, N = 10000;
	double X, X_sum, low, high;
	double Xi[n];
	double cent[N];
	int bunpu[_n];
	for(j = 0; j < N; j++){
		X = 0.0;
		X_sum = 0.0;
		for(i = 0; i < n; i++){
			Xi[i] = (double)rand() / (RAND_MAX + 1.0);
			X_sum += Xi[i];
		}
		X = (double)(X_sum - n / 2.0) / sqrt(n / 12.0);
		for(k = 0; k < _n; k++){
			low = -3.0 + 0.2 * k;
			high = low + 0.2;
			if(low < X && X < high){ 
				cent[k]++;
				break;
			}
		}
	}
	for(i = 0; i < _n; i++) bunpu[i] = cent[i] / 20;
	for(i = 0; i < _n; i++){
		for(j = 0; j < bunpu[i]; j++) printf("*");
		printf("\n");
	}
	return 0;
}
