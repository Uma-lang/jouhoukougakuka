#include<stdio.h>
int kaijo(int n);
int main(){
	int n = 10;
	printf("n = %d, kaijo = %d\n", n, kaijo(n));
}
int kaijo(int n){
	if(n == 1) return 1;
	int x;
	x = kaijo(n - 1) * n;
	return x;
}
