#include<stdio.h>
int wa(int n);
int seki(int n);
int main(){
	int n = 5;
	printf("n = %d, wa = %d, seki = %d\n", n, wa(n), seki(n));
}
int wa(int n){
	if(n == 0) return 1;
	int x;
	x = wa(n - 1) + (2 * n + 1);
	return x;
}
int seki(int n){
	if(n == 0) return 1;
	int y;
	y = seki(n - 1) * (2 * n + 1);
	return y;
}
