#include<stdio.h>
int kaijo(int n);
int main(){
	int i,j;
	int A_B = 3, B_C = 6;
	char a_b[] = {'1', '2', '3'};
	char b_c[] = {'a', 'b', 'c', 'd', 'e', 'f'};
	int true_value; 
	for(i = 0; i < A_B; i++){
		for(j = 0; j < B_C; j++){
			printf("(%c,%c)", a_b[i], b_c[j]);
		}
		printf("\n");
	}
	true_value = 3 * 6;
	printf("path ha %dhonaru.\n", true_value);
	return 0;
}
