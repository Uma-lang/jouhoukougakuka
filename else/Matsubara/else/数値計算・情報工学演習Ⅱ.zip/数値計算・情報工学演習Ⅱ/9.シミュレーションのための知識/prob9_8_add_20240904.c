#include<stdio.h>
int kaijo(int n);
int max(int a, int b){
	if(a > b) return a;
	else return b;
}
int min(int a, int b){
	if(a > b) return b;
	else return a;
}
int S(int n,int m,int k){
	return  (k + m) * min(0, k + m + 1) / 2 - (k + n - 1) * min(0, k + n) / 2;
}
int hukugen(int n, int k){
	int red, blue, white;
	int true_value;
	int cnt_hukugen = 0;
	printf("(red,blue,white) = \n");
	for(red = 0; red <= k; red++){
		for(blue = 0; blue <= k - red; blue++){
			white = k - red - blue;
			printf("(%d,%d,%d)\n", red, blue, white);
			cnt_hukugen++;
		}
	}
	true_value = kaijo(n + k - 1) / kaijo(k) / kaijo(n - 1);
	printf("true value = %d\n", true_value);
	printf("count hukugen = %d\n", cnt_hukugen);
	return 0;
}
int hihukugen(int n, int k, int red_max, int blue_max, int white_max){
	int m0, M0;
	int red, blue, white;
	//int red_max = 4, blue_max = 3, white_max = 2;
	int N = red_max + blue_max + white_max;
	int true_value;
	int cnt_hihukugen = 0;
	for(red = 0; red <= red_max; red++){
		if(red > k) break;
		for(blue = 0; blue <= blue_max; blue++){
			if(red + blue > k) break;
			white = k - red - blue;
			if(white >= 0 && white <= white_max){
				printf("(%d,%d,%d)\n", red, blue, white);
				cnt_hihukugen++;
			}
		}
	}
	m0 = min(white_max, k);
	M0 = max(0, k - (red + blue));
	true_value = S(-m0, -M0, k - blue_max) + S(M0, m0, red_max - k) + (blue_max + 1) * (m0 - M0 + 1);
	printf("true value = %d\n", true_value);
	printf("count hihukugen = %d\n", cnt_hihukugen);
	return 0;
}
int main(){
	int n = 3, k, red_max, blue_max, white_max;
	printf("k = ");
	scanf("%d", &k);
	printf("red max = ");
	scanf("%d", &red_max);
	printf("blue max = ");
	scanf("%d", &blue_max);
	printf("white max = ");
	scanf("%d", &white_max);
	hukugen(n,k);
	hihukugen(n, k, red_max, blue_max, white_max);
	return 0;
}
int kaijo(int n){
	if(n == 0 || n == 1) return 1;
	int x;
	x = kaijo(n - 1) * n;
	return x;
}
