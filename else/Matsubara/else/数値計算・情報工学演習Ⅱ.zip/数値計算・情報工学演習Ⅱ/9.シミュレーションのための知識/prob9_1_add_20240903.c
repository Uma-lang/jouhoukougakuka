#include<stdio.h>
#include<stdlib.h>
#include<time.h>
double prob9_1(int N){
	int i, n = 0.0;
	double random, ratio;
	for(i = 0; i < N; i++){
		random = (double)rand() / (RAND_MAX + 1.0) * 5;
		if(random >= 1.0 && random < 2.0) n++;
	}
	ratio = (double)n / N;
	return ratio;
}
int main(){
	srand(time(NULL));
	int i, N = 1;
	double ratio;
	for(i = 0; i < 5; i++){
		N *=10;
		ratio = prob9_1(N);
		printf("N = %d, ratio = %f\n", N, ratio);
	}
	return 0;
}
