#include <stdio.h>
#include <math.h>

int main(){
	double x=M_PI/4.0;
	double y=sin(x);;
	double true_ans=sqrt(2.0)/2.0;
	printf("sin(pi/4)=%f\n",y);
	printf("sqrt(2)/2=%f\n",true_ans);
	printf("error=%f\n",y-true_ans);
	return 0;
}
