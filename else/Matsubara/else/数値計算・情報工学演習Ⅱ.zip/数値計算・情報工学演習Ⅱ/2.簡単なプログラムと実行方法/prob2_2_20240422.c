#include <stdio.h>
int main(){
	double a=1/2;
	double b=1.0/2.0;
	printf("a=%f b=%f\n",a,b);
	
	double c=2.0, d=3.0, e=4.0, f=6.0;
	double x=c*d/e*f;
	double y=c*d/(e*f);
	double z=c*d/e/f;
	printf("x=%f y=%f z=%f\n",x,y,z);
	double s=1.0/3.0;
	double t=4.0/3.0;
	double p=2.0*(s*s+1.0)/(5.0*t);
	printf("s=%f t=%f p=%f\n",s,t,p);
	return 0;
}

