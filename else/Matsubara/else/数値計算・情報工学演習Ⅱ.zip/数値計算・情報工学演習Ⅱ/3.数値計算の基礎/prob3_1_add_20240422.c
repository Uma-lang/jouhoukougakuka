#include <stdio.h>
#include<math.h>
#include<fpu_control.h>
int main(){
	unsigned int flag = _FPU_SINGLE;
	unsigned short cw;
	_FPU_GETCW(cw);
	cw=(cw & ~0x300) | flag;
	_FPU_SETCW(cw);

	float x=0.00000000000025344,y1,y2;
	y1=1.0-1.0/pow(1.0+x,1.0/2.0);
	y2=x/pow(1.0+x,1.0/2.0)/(pow(1.0+x,1.0/2.0)+1.0);
	printf("x=%.20e\n",x);
	printf("y1=%.20e\n",y1);
	printf("y2=%.20e\n",y2);
	float y1_seido=y1*y1-2.0*y1+x/(x+1.0);
	float y2_seido=y2*y2-2.0*y2+x/(x+1.0);
	printf("x1�̐��x:%.20e\n",y1_seido);
	printf("y2�̐��x:%.20e\n",y2_seido);
	return 0;
}

