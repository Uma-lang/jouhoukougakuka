#include<stdio.h>
#include<math.h>
#include<fpu_control.h>
int main(){
	unsigned int flag=_FPU_SINGLE;
	unsigned short cw;
	_FPU_GETCW(cw);
	cw=(cw&~0x300) | flag;
	_FPU_SETCW(cw);

	int N=300000;
	int i,j;
	float x=0.0000000001;
	float a,c=1.0;
 
	//e^x-1
	float d = exp(x) - 1 ;
 
	//expm1(x)
	a=expm1(x);
	/*
	//x+x^2/2!=+x^3/3!+...
	for(i=3;i<=N;i++){
	b = b + pow(x,i+1) / _b ;
	_b *= i ;
 	}
	*/
	//x(1+2/x(1+x/3(1+...)))
	for(i = N ; i > 1 ; i--){
		c = 1 + x / i * c ;
 	}
 	c *= x ;

 	float e_ex = fabsf(a - d) ;
	float e_for = fabsf(a - c) ;
	printf("ketaochi_ari\n");
	printf("N=%d\nx=%.10e\n",N,x);
	//printf("e^x-1=%.10e\nx+x^2/2!=+x^3/3!+...=%.10e\nx(1+2/x(1+x/3(1+...)))=%.10e\n",a,b,c);
	printf("exp(x)-1=%.10e\nexpm1=%.10e\nx(1+2/x(1+x/3(1+...)))=%.10e\n",d,a,c);
	printf("error(e^x-1)=%.10e\nerror(for)=%.10e\n",e_ex,e_for);
	return 0;
}