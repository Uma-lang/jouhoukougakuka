#include <stdio.h>
#include <math.h>
int main(){
	int N=250;
	float s1,s2;
	int i;
	s1=0.0,s2=0.0;
	printf("N=%d\n",N);
	//情報落ちあり
	for(i=1;i<=N;i++){
		s1 = s1 + 1.0 /((float)i*i);
	}
	printf("sum(original)=%.8e\n",s1);
	//情報落ちなし
	for(i=N;i>=1;i--){
		s2 = s2 + 1.0 /((float)i*i);
	}
	printf("sum(high_accuracy=%.8e\n",s2);
	float true_value=M_PI*M_PI/6;
	printf("true_value=%f\n",true_value);
	float error_s1 = s1 - true_value;
	float error_s2 = s2 - true_value;
	printf("error(original)=%f\n",error_s1);
	printf("error(high_accuracy)=%f\n",error_s2);
	return 0;
}


