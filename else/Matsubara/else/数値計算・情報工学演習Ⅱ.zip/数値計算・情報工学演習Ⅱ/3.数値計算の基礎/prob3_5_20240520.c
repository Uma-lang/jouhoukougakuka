#include <stdio.h>
#include <math.h>
double fx(double x){
	double y = x / (x * x + 1)+1;
	return y;
}
int main(){
	int k,n=40;
	double f,x,x0=-2.0,h=4.0/n;
	double fmax=fx(x0), fmin=fx(x0), xmax, xmin;
	for (k=0;k<=n;k++){
		x=x0+h*k;
		f=x/(x*x+1)+1;
		if(f>fmax){
			fmax=f;
			xmax=x;
		}
		if(f<fmin){
			fmin=f;
			xmin=x;
		}
	}
	printf("fmax=%lf\nxmax=%lf\nfmin=%lf\nxmin=%lf\n",fmax,xmax,fmin,xmin);
	return 0;
}