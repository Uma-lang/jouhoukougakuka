#include<stdio.h>
#include<math.h>
#include<fpu_control.h>
int main(){
	unsigned int flag=_FPU_SINGLE;
	unsigned short cw;
	_FPU_GETCW(cw);
	cw=(cw&~0x300) | flag;
	_FPU_SETCW(cw);

	float theta=2.0, x=2.0, _x=1.0;

	float a=1.0-cosf(theta);
	float b=2.0*sinf(theta/2.0)*sinf(theta/2.0);
	printf("theta=%.10e\nx=%.10e\ndelta_x=%.10e\n",theta,x,_x);
	printf("cos(theta)=%.10e\nsin(theta)=%.10e\n",cosf(theta),sinf(theta));
	printf("1-cos(theta)=%.10e\n2*sin(theta/2)^2=%.10e\n",a,b);

	float c=sinf(x+_x)-sinf(x);
	float d=2.0*cosf(x+_x/2.0)*sinf(_x/2.0);
	printf("sin(x+delta_x)-sin(x)=%.10e\n2*cos(x+delta_x/2)*sin(delta_x/2)=%.10e\n",c,d);
	
	return 0;
}
//ketaotinashi
