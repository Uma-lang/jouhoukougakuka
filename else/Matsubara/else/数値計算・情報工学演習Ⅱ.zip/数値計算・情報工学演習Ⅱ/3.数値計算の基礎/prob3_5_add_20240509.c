#include<stdio.h>
#include<math.h>
#include<fpu_control.h>
int main(){
	unsigned int flag=_FPU_SINGLE;
	unsigned short cw;
	_FPU_GETCW(cw);
	cw=(cw&~0x300) | flag;
	_FPU_SETCW(cw);
	
	int i;
	int N=100;
	float x=2.309445858;
	float p=1.0;
	float array[N+1];
	float a=0.000005,d=0.000002,r=x;
	float s1=0.0,s2=0.0,s3;
	
	for(i=0;i<=N;i++){
		array[i]=(a+i*d);
	}

	//for
	for (i=0;i<=N;i++){
		s1+=array[i]*p;
		p*=x;
	}
	
	//horner
	for (i=N;i>=0;i--){
		s2=s2*x+array[i];
	}
	
	//formula
	s3=(a-(a+N*d)*pow(r,N+1.0))/(1.0-r)+d*r*(1.0-pow(r,N))/(1.0-r)/(1.0-r);

	//error
	float e1=fabsf(s3-s1);
	float e2=fabsf(s3-s2);
	printf("high accuracy parameter\n");
	printf("N=%d\nx=%.10e\narray[n]=%f+%fn\n",N,x,a,d);
	printf("sum(for)=%.20e\nsum(horner)=%.20e\nsum(formula)=%.20e\n",s1,s2,s3);
	printf("error(for)=%.20e\nerror(honor)=%.20e\n",e1,e2);
	
	return 0;
}

