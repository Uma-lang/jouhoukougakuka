#include <stdio.h>
#include <math.h>
int main(){
	float a=0.2,b=-500.0,c=0.7;
	float x1_ori,x2_ori,x1_acc,x2_acc;
	printf("a=%f\nb=%f\nc=%f\n",a,b,c);
	//桁落ちがある場合
	x1_ori=(-b-sqrt(b*b-4*a*c))/(2*a);
	x2_ori=(-b+sqrt(b*b-4*a*c))/(2*a);
	printf("x1(original)=%f\nx2(original)=%f\n",x1_ori,x2_ori);

	//桁落ちがない場合
	if(b>=0){
		x1_acc=(-b-sqrt(b*b-4*a*c))/(2*a);
	}
	else{
		x1_acc=(-b+sqrt(b*b-4*a*c))/(2*a);
	}
	x2_acc=c/a/x1_acc;
	printf("x1(high_accuracy)=%f\nx2(high_accuracy)=%f\n",x1_acc,x2_acc);
	float Relation_roots_coefficient_origin=x1_ori+x2_ori+b/a;
	printf("Relation_roots_coefficient(original)=%f\n",Relation_roots_coefficient_origin);
	float Relation_roots_coefficient_high_accuracy=x1_acc+x2_acc+b/a;
	printf("Relation_roots_coefficient(high_accuracy)=%f\n",Relation_roots_coefficient_high_accuracy);
	float sub_x1_ori=a*x1_ori*x1_ori+b*x1_ori+c;
	float sub_x2_ori=a*x2_ori*x2_ori+b*x2_ori+c;
	printf("substitution with x1(original)=%f\n",sub_x1_ori);
	printf("substitution with x2(original)=%f\n",sub_x2_ori);
	float sub_x1_acc=a*x1_acc*x1_acc+b*x1_acc+c;
	float sub_x2_acc=a*x2_acc*x2_acc+b*x2_acc+c;
	printf("substitution with x1(high_accurasy)=%f\n",sub_x1_acc);
	printf("substitution with x2(high_accuracy)=%f\n",sub_x2_acc);
	return 0;
}
