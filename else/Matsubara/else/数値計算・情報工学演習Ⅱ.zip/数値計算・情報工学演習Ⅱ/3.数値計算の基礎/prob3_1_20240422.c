#include <stdio.h>
int main(){
	int n=8;
	float s;
	int i;
	s=0.0;
	for(i=0;i<n;i++){
		s = s + 1.0 / (float)n;
	}
	printf("i:%d s:%.8e\n",i,s);
	return 0;
}
