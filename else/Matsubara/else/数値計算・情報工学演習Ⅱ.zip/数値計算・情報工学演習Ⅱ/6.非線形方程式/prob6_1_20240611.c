#include<stdio.h>
#include<math.h>

double f(double x){
	return tan(x) - 2.0 * x;
}

double df(double x){
	return 1.0 / cos(x) / cos(x) - 2.0;
}

double bisection(int N, double eps, double delta){
	int i = 0;
	double a = M_PI / 4.0 * 1.1, b = M_PI / 2.0 * 0.9;
	double c, c1, x;
	c1 = a;
	for(i = 0; i < N; i++){
		c = (a + b) / 2.0;
		if(f(c) == 0.0 || fabs(f(c)) < delta || fabs(c - c1) < eps){
			x = c;
			break;
		}
		else if(f(a) * f(c) < 0.0){
			b = c;
		}
		else if(f(a) * f(c) > 0.0){
			a = c;
		}
		c1 = c;
	}
	printf("---- bisection method ----\n");
	printf("x = %.10e\nf(x) = %.10e\ninteration = %d\n", x, f(x), i);
}
double newton(int N, double eps, double delta){
	int i = 0;
	double x0 = 1.0;
	double x;
	for(i = 0; i < N; i++){
		double x1 = x0 - f(x0) / df(x0);
		if(fabs(x1 - x0) < eps || fabs(f(x1)) < delta){ 
			x = x1;
			break;
		}
		x0 = x1;
	}
	printf("---- Newton's method ----\n");
	printf("x = %.10e\nf(x) = %.10e\ninteration = %d\n", x, f(x), i);
}
	
int main(){
	int N = 100;
	double eps = 1e-9, delta = 1e-9;
	bisection(N, eps, delta);
	newton(N, eps, delta);
	return 0;
}
