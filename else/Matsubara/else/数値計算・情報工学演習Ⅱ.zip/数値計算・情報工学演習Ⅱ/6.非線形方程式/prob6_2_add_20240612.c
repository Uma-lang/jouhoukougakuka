#include<stdio.h>
#include<stdlib.h>
#include<math.h>
double f1(double x, double y){
	return x * x + y * y - 3.0;
}
double df1dx(double x, double y){
	return 2.0 * x;
}
double df1dy(double x, double y){
	return 2.0 * y;
}
double f2(double x, double y){
	return x * y - 1.0;
}
double df2dx(double x, double y){
	return y;
}
double df2dy(double x, double y){
	return x;
}
int main(){
	int i, j, k, l;
	int N = 100;
	double x, x0 = 1.0, x1 = 2.0, y, y0 = 2.0, y1 = 1.0;
	double eps = 1e-12, delta = 1e-12;
	double J[2][2], determinant, J_inv[2][2], s;
	double X[2][1];
	double X0[2][1] = {
			{x0},
			{y0}
			};
	double X1[2][1];
	double F[2][1], S[2][1];
	for(l = 0; l < N; l++) {
		F[0][0] = f1(X0[0][0], X0[1][0]);
		F[1][0] = f2(X0[0][0], X0[1][0]);
	
		J[0][0] = df1dx(X0[0][0], X0[1][0]);
		J[0][1] = df1dy(X0[0][0], X0[1][0]);
		J[1][0] = df2dx(X0[0][0], X0[1][0]);
		J[1][1] = df2dy(X0[0][0], X0[1][0]);
	
		determinant = J[0][0] * J[1][1] - J[0][1] * J[1][0];
	
		J_inv[0][0] = J[1][1] / determinant;
		J_inv[0][1] = -J[0][1] / determinant;
		J_inv[1][0] = -J[1][0] / determinant;
		J_inv[1][1] = J[0][0] / determinant;
	
		for(i = 0; i < 2; i++) {
			s = 0.0;
			for(k = 0; k < 2; k++) {
				s += J_inv[i][k] * F[k][0];
			}
			S[i][0] = s;
		}
	
		for(i = 0; i < 2; i++) {
			X1[i][0] = X0[i][0] - S[i][0];
		}
	
		if(fabs(X1[0][0] - X0[0][0]) + fabs(X1[1][0] - X0[1][0]) < eps || (fabs(f1(X1[0][0], X1[1][0])) + fabs(f2(X1[0][0], X1[1][0])) < delta)) {
			X[0][0] = X1[0][0];
			X[1][0] = X1[1][0];
			break;
		}
		else{
			X0[0][0] = X1[0][0];
			X0[1][0] = X1[1][0];
		}
	}
	double absF = fabs(f1(X1[0][0], X1[1][0])) + fabs(f2(X1[0][0], X1[1][0]));
	printf("x = %.10e\n", X[0][0]);
	printf("y = %.10e\n", X[1][0]);
	printf("|F(X)| = %.10e\n", absF);
	printf("iteration = %d\n", i);
	return 0;
}

