#include<stdio.h>
#include<math.h>
double f(double x, double a){
	return x * x - a;
}
double df(double x){
	return 2.0 * x;
}
double myfabs(double a){
	if(a >= 0.0){
		return  a;
	}
	else{
		return - a;
	}
}
double mysqrt(double a){
	double eps = 1e-9, delta = 1e-9;
	int i, N = 100;
	double x, x0 = 1.0, x1;
	for(i = 0; i < N; i++){
		x1 = x0 - f(x0, a) / df(x0);
		if(myfabs(x1 - x0) < eps || myfabs(f(x1, a)) < delta){
			x = x1;
			break;
		}
		else{
			x0 = x1;
		}
	}
	return x;
}
int main(){
	double sqrt_pi = sqrt(M_PI);
	double mysqrt_pi = mysqrt(M_PI);
	double error_sqrt = sqrt_pi - mysqrt_pi;
	printf("sqrt pi = %.12e\n",sqrt_pi);
	printf("mysqrt pi = %.12e\n",mysqrt_pi);
	printf("error(sqrt) = %.12e\n", error_sqrt);
	return 0;
}

