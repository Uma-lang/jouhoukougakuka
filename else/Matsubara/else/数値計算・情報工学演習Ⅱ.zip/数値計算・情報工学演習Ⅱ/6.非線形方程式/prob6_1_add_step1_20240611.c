#include<stdio.h>
#include<math.h>
int main(){
	int i;
	double a0 = 1.0, b0 = 1.0 / sqrt(2.0), t0 = 1.0 / 4.0, p0 = 1.0, eps = 1e-9;
	double anp1, an, bnp1, bn, tnp1, tn, pnp1, pn, pi;
	an = a0, bn = b0, tn = t0, pn = p0;
	for(i = 2; i < 100; i++){
		anp1 = (an + bn) / 2.0;
		bnp1 = sqrt(an * bn);
		tnp1 = tn - pn * (an - anp1) * (an - anp1);
		pnp1 = 2.0 * pn;
		if(fabs(anp1 - an) < eps && fabs(bnp1 - bn) < eps){
			pi = (anp1 + bnp1) * (anp1 + bnp1) / 4.0 / tnp1;
			break;
		}
		else{
			an = anp1, bn = bnp1, tn = tnp1, pn = pnp1;
		}
	}
	double error = M_PI - pi;
	printf("iteration = %d\n", i);
	printf("my pi = %.12e\n", pi);
	printf("true pi = %.12e\n",M_PI);
	printf("error = %.12e\n", error);
	return 0;
}

