#include<stdio.h>
#include<math.h>
double dxdt(double t, double x, double y){ //dydt = f(x, y);
	return y;
}
double dydt(double t, double x, double y){
	return -20.0 * x - y * t;
}
int main(){
	double h = 0.01;
	int n, N = 10 / h;
	double t_n = 0.0;
	double x0 = 1.0, x_n_rk = x0, x_np1_rk;
	double y0 = 0.0, y_n_rk = y0, y_np1_rk;
	FILE *fp;
	//Euler & Runge_Kutta
	fp = fopen("output8_5_add.csv","w");
	if(fp ==  NULL){
		printf("file open error\n");
		return 1;
	}
	fprintf(fp, "t,x_runge-kutta\n");
	for(n = 0; n <= N; n++){
		double k_x_1 = h * dxdt(t_n, x_n_rk, y_n_rk);
		double k_y_1 = h * dydt(t_n, x_n_rk, y_n_rk);
		double k_x_2 = h * dxdt(t_n + h / 2.0, x_n_rk + k_x_1 / 2.0, y_n_rk + k_y_1 / 2.0);
		double k_y_2 = h * dydt(t_n + h / 2.0, x_n_rk + k_x_1 / 2.0, y_n_rk + k_y_1 / 2.0);
		double k_x_3 = h * dxdt(t_n + h / 2.0, x_n_rk + k_x_2 / 2.0, y_n_rk + k_y_2 / 2.0);
		double k_y_3 = h * dydt(t_n + h / 2.0, x_n_rk + k_x_2 / 2.0, y_n_rk + k_y_2 / 2.0);
		double k_x_4 = h * dxdt(t_n + h, x_n_rk + k_x_3, y_n_rk + k_y_3);
		double k_y_4 = h * dydt(t_n + h, x_n_rk + k_x_3, y_n_rk + k_y_3);
		x_np1_rk = x_n_rk + (k_x_1 + 2.0 * k_x_2 + 2.0 * k_x_3 + k_x_4) / 6.0;
		y_np1_rk = y_n_rk + (k_y_1 + 2.0 * k_y_2 + 2.0 * k_y_3 + k_y_4) / 6.0;

		fprintf(fp, "%f,%f\n", t_n, x_n_rk);
		printf("t = %f, x(runge-kutta) = %f\n", t_n, x_n_rk);
		printf("------------------------------------------------------------------------------------------------------------------------------------------------------\n");

		t_n += h;
		x_n_rk = x_np1_rk;
		y_n_rk = y_np1_rk;
	}
	fclose(fp);
	return 0;
}
	
