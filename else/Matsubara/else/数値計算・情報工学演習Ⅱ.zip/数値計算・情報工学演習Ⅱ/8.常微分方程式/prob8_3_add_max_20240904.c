#include<stdio.h>
#include<math.h>
double dxdt(double x, double y, double vx, double vy){
	return vx;
}
double dydt(double x, double y, double vx, double vy){
	return vy;
}
double dvxdt(double x, double y, double vx, double vy){
	double b2 = 0.15;
	double m = 1.0;
	return -b2 / m * vx * sqrt(vx * vx + vy * vy);
}
double dvydt(double x, double y, double vx, double vy){
	double b2 = 0.15;
	double m = 0.1;
	double g = 9.8;
	return -g - b2 / m * vy * sqrt(vx * vx + vy * vy);
}
	
int main(){
	double kakudo, kakudo_max = 0.0;
	double x_max = 0.0;
	FILE *fp;
	fp = fopen("output8_3_add_max_20240903.csv","w");
	if(fp ==  NULL){
		printf("file open error\n");
		return 1;
	}
	fprintf(fp, "kakudo,x,y\n");
	for(kakudo = 38; kakudo < 43; kakudo++){
		double h = 0.001;
		int n, N = 30 / h;
		double t = 0.0;
		double theta = kakudo * M_PI / 180.0;
		double x0 = 0.0, x = x0, _x;
		double y0 = 0.0, y = y0;
		double v0 = 10.0;
		double vx0 = v0 * cos(theta), vx = vx0;
		double vy0 = v0 * sin(theta), vy = vy0;
		for(n = 0; n <= N; n++){
			double k_x_1 = h * dxdt(x, y, vx, vy);
			double k_vx_1 = h * dvxdt(x, y, vx, vy);
			double k_y_1 = h * dydt(x, y, vx, vy);
			double k_vy_1 = h * dvydt(x, y, vx, vy);
			double k_x_2 = h * dxdt(x + k_x_1 / 2.0, y + k_y_1 / 2.0, vx + k_vx_1 / 2.0, vy + k_vy_1 / 2.0);
			double k_vx_2 = h * dvxdt(x + k_x_1 / 2.0, y + k_y_1 / 2.0, vx + k_vx_1 / 2.0, vy + k_vy_1 / 2.0);
			double k_y_2 = h * dydt(x + k_x_1 / 2.0, y + k_y_1 / 2.0, vx + k_vx_1 / 2.0, vy + k_vy_1 / 2.0);
			double k_vy_2 = h * dvydt(x + k_x_1 / 2.0, y + k_y_1 / 2.0, vx + k_vx_1 / 2.0, vy + k_vy_1) / 2.0;
			double k_x_3 = h * dxdt(x + k_x_2 / 2.0, y + k_y_2 / 2.0, vx + k_vx_2 / 2.0, vy + k_vy_2 / 2.0);
			double k_vx_3 = h * dvxdt(x + k_x_2 / 2.0, y + k_y_2 / 2.0, vx + k_vx_2 / 2.0, vy + k_vy_2 / 2.0);
			double k_y_3 = h * dydt(x + k_x_2 / 2.0, y + k_y_2 / 2.0, vx + k_vx_2 / 2.0, vy + k_vy_2 / 2.0);
			double k_vy_3 = h * dvydt(x + k_x_2 / 2.0, y + k_y_2 / 2.0, vx + k_vx_2 / 2.0, vy + k_vy_2 / 2.0);
			double k_x_4 = h * dxdt(x + k_x_3, y + k_y_3, vx + k_vx_3, vy + k_vy_3);
			double k_vx_4 = h * dvxdt(x + k_x_3, y + k_y_3, vx + k_vx_3, vy + k_vy_3);
			double k_y_4 = h * dydt(x + k_x_3, y + k_y_3, vx + k_vx_3, vy + k_vy_3);
			double k_vy_4 = h * dvydt(x + k_x_3, y + k_y_3, vx + k_vx_3, vy + k_vy_3);
			x += (k_x_1 + 2.0 * k_x_2 + 2.0 * k_x_3 + k_x_4) / 6.0;
			vx += (k_vx_1 + 2.0 * k_vx_2 + 2.0 * k_vx_3 + k_vx_4) / 6.0;
			y += (k_y_1 + 2.0 * k_y_2 + 2.0 * k_y_3 + k_y_4) / 6.0;
			vy += (k_vy_1 + 2.0 * k_vy_2 + 2.0 * k_vy_3 + k_vy_4) / 6.0;
			if(y < 0.0){
				break;
			}
			printf("kakudo = %f, x = %f, y = %f\n", kakudo, x, y);
			fprintf(fp, "%f,%f,%f\n",kakudo, x, y);
			t += h;
		}
		if(x > x_max){
			x_max = x;
			kakudo_max = kakudo;
		}
	}
	fclose(fp);
	printf("x_max = %f, kakudo_max = %f\n", x_max, kakudo_max);
	return 0;
}
