#include<stdio.h>
#include<math.h>
double f(double x, double dxdt, double beta, double m, double k){
	return -beta / m * dxdt - k / m * x;
}
double dxdt(double x, double y, double beta, double m, double k){
	return y;
}
double dydt(double x, double y, double beta, double m ,double k){
	return -beta / m * y - k / m * x;
}
int main(){
	double h = 0.01;
	int n, N = 30 / h;
	double t_n = 0.0;
	double x0 = 1.0, x_n_rk = x0, x_np1_rk;
	double x_n_edm = x0, x_np1_edm, x_n_log;
	double dxdt_0 = 0.0, dxdt_n = dxdt_0, dxdt_np1;
	double y0 = dxdt_0, y_n_rk = y0, y_np1_rk;
	//double beta = 1.5, m = 1.0, k = 6.25;	//D < 0
	//double beta = 2.5, m = 1.0, k = 6.25;	//D = 0
	double beta = 3.5, m = 1.0, k = 6.25;	//D > 0
	FILE *fp;
	//Euler & Runge_Kutta
	fp = fopen("output8_4_add_dGT0_20240904.csv","w");
	if(fp ==  NULL){
		printf("file open error\n");
		return 1;
	}
	fprintf(fp, "t,x(runge-kutta),x(edm),x(log)\n");
	for(n = 0; n <= N; n++){
		//Runge-Kutta
		double k_x_1 = h * dxdt(x_n_rk, y_n_rk, beta, m, k);
		double k_y_1 = h * dydt(x_n_rk, y_n_rk, beta, m ,k);
		double k_x_2 = h * dxdt(x_n_rk + k_x_1 / 2.0, y_n_rk + k_y_1 / 2.0, beta, m, k);
		double k_y_2 = h * dydt(x_n_rk + k_x_1 / 2.0, y_n_rk + k_y_1 / 2.0, beta, m ,k);
		double k_x_3 = h * dxdt(x_n_rk + k_x_2 / 2.0, y_n_rk + k_y_2 / 2.0, beta, m ,k);
		double k_y_3 = h * dydt(x_n_rk + k_x_2 / 2.0, y_n_rk + k_y_2 / 2.0, beta, m ,k);
		double k_x_4 = h * dxdt(x_n_rk + k_x_3, y_n_rk + k_y_3, beta, m ,k);
		double k_y_4 = h * dydt(x_n_rk + k_x_3, y_n_rk + k_y_3, beta, m , k);
		x_np1_rk = x_n_rk + (k_x_1 + 2.0 * k_x_2 + 2.0 * k_x_3 + k_x_4) / 6.0;
		y_np1_rk = y_n_rk + (k_y_1 + 2.0 * k_y_2 + 2.0 * k_y_3 + k_y_4) / 6.0;

		//Explicit Difference Method
		x_np1_edm = x_n_edm + h * dxdt_n + h * h / 2.0 * f(x_n_edm, dxdt_n, beta, m ,k);
		dxdt_np1 = dxdt_n + h * f(x_n_edm, dxdt_n, beta, m, k);

		//log
		double A, B,b, b1, b2, omega;
		double D = beta * beta - 4.0 * k * m;
		if(D < 0){
			omega = sqrt(-D) / 2.0 / m;
			b = beta / 2.0 / m;
			A = beta * x0 / sqrt(-D);
			B = x0;
			x_n_log = exp(-b * t_n) * (A * sin(omega * t_n) + B * cos(omega * t_n));
		}
		else if(D == 0){
			b = beta / 2.0 / m;
			A = x0;
			B = b * x0;
			x_n_log = exp(-b * t_n) * (A + B * t_n);
		}
		else{
			b1 = (beta - sqrt(D)) / 2.0 / m;
			b2 = (beta + sqrt(D)) / 2.0 / m;
			A = (D + beta * sqrt(D)) * x0 / 2.0 / D;
			B = (D - beta * sqrt(D)) * x0 / 2.0 / D;
			x_n_log = A * exp(-b1 * t_n) + B * exp(-b2 * t_n);
		}
			

		fprintf(fp, "%f,%f,%f,%f\n", t_n, x_n_rk, x_n_edm, x_n_log);
		printf("t = %f, x(runge-kutta) = %f, x(explicit difference) = %f, x(log) = %f\n", t_n, x_n_rk, x_n_edm, x_n_log);
		printf("------------------------------------------------------------------------------------------------------------------------------------------------------\n");

		//time
		t_n += h;
		x_n_rk = x_np1_rk;
		y_n_rk = y_np1_rk;
		x_n_edm = x_np1_edm;
		dxdt_n = dxdt_np1;

	}
	fclose(fp);
	return 0;
}
	
