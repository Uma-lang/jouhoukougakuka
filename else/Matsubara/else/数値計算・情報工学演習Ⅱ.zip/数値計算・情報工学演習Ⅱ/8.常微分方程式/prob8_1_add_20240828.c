#include<stdio.h>
#include<math.h>
double dxdt(double x, double y){	//dxdt = f(x, y)
	return -y + 3.0 / 5.0 * x;
}
double dydt(double x, double y){ //dydt = f(x, y);
	return 4.0 * x - y;
}
int main(){
	double h = 0.2;
	int n, N = 10 / h;
	double t_n = 0.0;
	double x0 = 1.0, x_n_euler = x0, x_np1_euler, x_n_rk = x0, x_n_log = x0;
	double y0 = 0.0, y_n_euler = y0, y_np1_euler, y_n_rk = y0, y_n_log = y0;
	FILE *fp;
	//Euler & Runge_Kutta
	fp = fopen("output8_1_add.csv","w");
	if(fp ==  NULL){
		printf("file open error\n");
		return 1;
	}
	fprintf(fp, "t,x_euler,x_runge-kutta,x_logistic,y_euler,y_runge-kutta,y_logistic\n");
	for(n = 0; n <= N; n++){
		//Logistic
		x_n_log = exp(-t_n / 5.0) / 42.0 * (42.0 * cos(2.0 * sqrt(21.0) / 5.0 * t_n) + 4.0 * sqrt(21.0) * sin(2.0 * sqrt(21.0) / 5.0 * t_n));
		y_n_log = exp(-t_n / 5.0) * 10.0 / sqrt(21.0) * sin(2.0 * sqrt(21.0) / 5.0 * t_n);

		//error
		double x_error_euler = fabs(x_n_euler - x_n_log);
		double x_error_rk = fabs(x_n_rk - x_n_log);
		double y_error_euler = fabs(y_n_euler - y_n_log);
		double y_error_rk = fabs(y_n_rk - y_n_log);

		fprintf(fp, "%f,%f,%f,%f,%f,%f,%f\n", t_n, x_n_euler, x_n_rk, x_n_log, y_n_euler, y_n_rk, y_n_log);
		printf("t = %f, x(euler) = %f, error(euler) = %f, x(runge-kutta) = %f, error(runge-kutta) = %f, x(logistic) = %f\n", t_n, x_n_euler, x_error_euler, x_n_rk, x_error_rk, x_n_log);
		printf("t = %f, y(euler) = %f, error(euler) = %f, y(runge-kutta) = %f, error(runge-kutta) = %f, y(logistic) = %f\n", t_n, y_n_euler, y_error_euler, y_n_rk, y_error_rk, y_n_log);
		printf("------------------------------------------------------------------------------------------------------------------------------------------------------\n");
		
		//Euler
		x_np1_euler = x_n_euler + h * dxdt(x_n_euler, y_n_euler);
		y_np1_euler = y_n_euler + h * dydt(x_n_euler, y_n_euler);
		x_n_euler = x_np1_euler;
		y_n_euler = y_np1_euler;
		
		//Runge-Kutta
		double k_x_1 = h * dxdt(x_n_rk, y_n_rk);
		double k_y_1 = h * dydt(x_n_rk, y_n_rk);
		double k_x_2 = h * dxdt(x_n_rk + k_x_1 / 2.0, y_n_rk + k_y_1 / 2.0);
		double k_y_2 = h * dydt(x_n_rk + k_x_1 / 2.0, y_n_rk + k_y_1 / 2.0);
		double k_x_3 = h * dxdt(x_n_rk + k_x_2 / 2.0, y_n_rk + k_y_2 / 2.0);
		double k_y_3 = h * dydt(x_n_rk + k_x_2 / 2.0, y_n_rk + k_y_2 / 2.0);
		double k_x_4 = h * dxdt(x_n_rk + k_x_3, y_n_rk + k_y_3);
		double k_y_4 = h * dydt(x_n_rk + k_x_3, y_n_rk + k_y_3);
		x_n_rk += (k_x_1 + 2.0 * k_x_2 + 2.0 * k_x_3 + k_x_4) / 6.0;
		y_n_rk += (k_y_1 + 2.0 * k_y_2 + 2.0 * k_y_3 + k_y_4) / 6.0;

		//time
		t_n += h;
	}
	fclose(fp);
	return 0;
}
	
