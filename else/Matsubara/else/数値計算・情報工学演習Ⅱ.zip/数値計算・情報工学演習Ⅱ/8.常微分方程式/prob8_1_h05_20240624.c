#include<stdio.h>
#include<math.h>

double dxdt(double t, double x){	//dxdt = f(t,x)
	return (1.0 - x) * x;
}
int main(){
	int n, N = 20;
	double h = 0.5;
	double t0 = 0.0, t_n, t_nm1;
	double x0 = 0.05, x_n_euler, x_np1_euler, x_n_rk, x_np1_rk, x_n_log;	//0.01<=x0<=0.1
	FILE *fp;
//Euler & Runge_Kutta
	fp = fopen("output_81.csv","w");
	fprintf(fp, "t,euler,runge-kutta,logistic\n");
	t_n = 0.0, t_nm1 = 0.0, x_n_euler = x0, x_np1_euler, x_n_rk = x0, x_np1_rk;
	for(n = 0; n <= N; n++){
		//Euler
		double f = dxdt(t_n, x_n_euler);
		x_np1_euler = x_n_euler + h * f;

		//Runge-Kutta
		double k1 = h * dxdt(t_n, x_n_rk);
		double k2 = h * dxdt(t_n + h / 2.0, x_n_rk + k1 / 2.0);
		double k3 = h * dxdt(t_n + h / 2.0, x_n_rk + k2 / 2.0);
		double k4 = h * dxdt(t_n + h, x_n_rk + k3);
		x_np1_rk = x_n_rk + (k1 + 2.0 * k2 + 2.0 * k3 + k4) / 6.0;

		//Logistic
		x_n_log = 1.0 / (1.0 + (1.0 / x0 - 1.0) * exp(-t_n));

		//error
		double error_euler = fabs(x_n_euler - x_n_log);
		double error_rk = fabs(x_n_rk - x_n_log);

		fprintf(fp, "%f,%f,%f,%f\n", t_n, x_n_euler, x_n_rk, x_n_log);
		printf("t = %f, x(euler) = %f, error(euler) = %f, x(runge-kutta) = %f, error(runge-kutta) = %f, x(logistic) = %f\n",
				t_n, x_n_euler, error_euler, x_n_rk, error_rk, x_n_log);
		x_n_euler = x_np1_euler;
		x_n_rk = x_np1_rk;
		t_n = t_nm1 + h;
		t_nm1 = t_n;
	}
/*
//Logistic
	t_n = 0.0, t_nm1 = 0.0;
	for(n = 0; n <= N; n++){
		x_n_log = 1.0 / (1.0 + (1.0 / x0 - 1.0) * exp(-t_n));
		printf("%f,%f\n", t_n, x_n_log);
		t_n = t_nm1 + h;
		t_nm1 = t_n;
	}
*/
	fclose(fp);
	return 0;
}
	
