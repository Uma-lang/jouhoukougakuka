#include<stdio.h>
#include<math.h>
double f(double x){
	double y;
	y = 1.0 / (x * x + 1.0);
	return y;
}
//合成台形公式
double trapezoidal(double a, double b,int n){
	double htr = (b - a) / (double) n;
	double sum_tr = 0;
	int i;
	for(i = 1; i < n; i++){
		double x = a + htr * i;
		sum_tr += f(x);
	}
	double tra = htr / 2.0 * (f(a) + 2 * sum_tr + f(b));
	return tra;
}
//合成第1シンプソン公式
double first_Simpson(double a, double b, int n){
	double hfs = (b - a) / 2.0 / n;
	double sum_fs_2i0 = 0, sum_fs_2i1 = 0;
	int i;
	for(i = 1; i < n * 2; i++){
		double x = a + hfs * i;
		if(i % 2 == 0){
			sum_fs_2i0 += f(x);
		}else{
			sum_fs_2i1 += f(x);
		}
	}
	double fs = hfs / 3.0 * (f(a) + 2.0 * sum_fs_2i0 + 4.0 * sum_fs_2i1 + f(b));
	return fs;
}
//合成第２シンプソン公式
double second_Simpson(double a, double b,int n){
	double hss = (b - a) / 3.0 / n;
	double sum_ss_3i0 = 0, sum_ss_3i1 = 0, sum_ss_3i2 = 0;
	int i;
	for(i = 1; i < n * 3; i++){
		double x = a + hss * i;
		if(i % 3 == 0){
			sum_ss_3i0 += f(x);
		}else if(i % 3 == 1){
			sum_ss_3i1 += f(x);
		}else{
			sum_ss_3i2 += f(x);
		}
	}
	double ss = 3.0 * hss / 8.0 *(f(a) + 2.0 * sum_ss_3i0 + 3.0 * sum_ss_3i1 + 3.0 * sum_ss_3i2 + f(b));
	return ss;
}
int main(){
	int i,n = 2000;
	double true_value = M_PI / 4.0;
	double a = 0.0, b = 1.0;
	printf("n = %d\n",n);
	double tra = trapezoidal(a,b,n);
	double fs = first_Simpson(a,b,n);
	double ss = second_Simpson(a,b,n);
	printf("trapezoidal = %.10e\n",tra);
	printf("first Simpson = %.10e\n",fs);
	printf("second Simpson = %.10e\n",ss);
	printf("treu value = %.10e\n",true_value);
	return 0;
}
