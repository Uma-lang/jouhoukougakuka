#include<stdio.h>
#include<math.h>

double f1(double x){
	double y = 1.0 / (x * x + 1.0);
	return y;
}
double f2(double x){
	double y = sqrt((x - 2) * (4 - x)) / 2.0;
	return y;
}
double I(double a, double b, int n, double f(double)){
	int i;
	double y,x,h;
	h = (b - a) / 3.0 / n;
	double sum_3i0=0.0, sum_3i1=0.0, sum_3i2=0.0;
	for(i = 0; i < 3 * n; i++){
		double x = a + i * h;
		if(i % 3 == 0){
			sum_3i0 += f(x);
		}
		else if(i % 3 == 1){
			sum_3i1 += f(x);
		}
		else{
			sum_3i2 += f(x);
		}
	}
	y = 3.0 * h / 8.0 * (f(a) + 2.0 * sum_3i0 + 3.0 * sum_3i1 + 3.0 * sum_3i2 + f(b));
	return y;
}
int main(){
	double I_1,I_2,I_;
	double a1 = 0.0, b1 = 1.0;
	double a2 = 2.0, b2 = 4.0;
	int n1 = 136200;
	int n2 = 500;
	double I1_true_value = M_PI / 4.0;
	double I2_true_value = M_PI / 4.0;
	double I_true_value = M_PI / 2.0;
	double e_I1, e_I2, e_I;
	I_1 = I(a1,b1,n1,f1);
	I_2 = I(a2,b2,n2,f2);
	I_ = I_1 + I_2;
	e_I1 = fabsf(I_1 - I1_true_value);
	e_I2 = fabsf(I_2 - I2_true_value);
	e_I = fabsf(I_ - I_true_value);
	printf("n1 = %d, n2 = %d\n",n1,n2);
	printf("I_1 = %.10e\n",I_1);
	printf("I_true_value = %.10e\n",I1_true_value);
	printf("error(I1) = %.10e\n",e_I1);
	printf("I_2 = %.10e\n",I_2);
	printf("I2_true_value = %.10e\n",I2_true_value);
	printf("error(I2) = %.10e\n",e_I2);
	printf("I = %.10e\n",I_);
	printf("I_true_value = %.10e\n",I_true_value);
	printf("error(I) = %.10e\n",e_I);
	return 0;
}