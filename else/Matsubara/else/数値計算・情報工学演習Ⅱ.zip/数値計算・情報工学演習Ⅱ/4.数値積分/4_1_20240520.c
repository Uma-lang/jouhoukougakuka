#include<stdio.h>
#include<math.h>

double f(double x){
	double y;
	y = 1.0 / (x * x + 1.0);
	return y;
}

int main(){
	double true_value = M_PI / 4.0;
	double a = 0.0,b = 1.0;
	double hfs = (b - a) / 2.0;
	double hss = (b - a) / 3.0;
	double tra = (b - a) / 2.0 * (f(b) + f(a));
	double fs = hfs / 3.0 * (f(a) + 4 * f(a + hfs) + f(b));
	double ss = 3.0 * hss / 8.0 *(f(a) + 3.0 * f(a + hss) + 3.0 * f(a + 2.0 * hss) + f(b));
	printf("trapezoidal = %.10e\n",tra);
	printf("first Simpson = %.10e\n",fs);
	printf("second Simpson = %.10e\n",ss);
	printf("treu value %.10e\n",true_value);

	return 0;
}
