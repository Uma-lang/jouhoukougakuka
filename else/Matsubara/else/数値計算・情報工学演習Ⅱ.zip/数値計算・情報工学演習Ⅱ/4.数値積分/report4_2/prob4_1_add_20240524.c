#include<stdio.h>
#include<math.h>
double f1(double x){
	return 1.0 / (x * x + 1.0);
}
double f2(double x){
	 return sqrt((x - 2) * (4 - x)) / 2.0;
}
double I(double a, double b, int n, double f(double)){
	int i;
	double h = (b - a) / 3.0 / n;
	double sum_3i0=0.0, sum_3i1=0.0, sum_3i2=0.0;
	for(i = 3; i < 3 * n; i+=3){
		double x = a + i * h;
		sum_3i0 += f(x);
	}
	for(i = 1; i < 3 * n; i+=3){
		double x = a + i * h;
		sum_3i1 += f(x);
	}
	for(i = 2; i < 3 * n; i+=3){
		double x = a + i * h;
		sum_3i2 += f(x);
	}
	return 3.0 * h / 8.0 * (f(a) + 2.0 * sum_3i0 + 3.0 * sum_3i1 + 3.0 * sum_3i2 + f(b));
}
int main(){
	double a1 = 0.0, b1 = 1.0;
	double a2 = 2.0, b2 = 4.0;
	double I1_true_value = M_PI / 4.0, I2_true_value = M_PI / 4.0, I_true_value = M_PI / 2.0;
	double I_1, I_2, I_, e_I1, e_I2, e_I;
	int n1 = 100, n2 = 200;
	if(n1 != n2){
		I_1 = I(a1,b1,n1,f1);
		I_2 = I(a2,b2,n2,f2);
		I_ = I_1 + I_2;
		e_I1 = fabs(I_1 - I1_true_value);
		e_I2 = fabs(I_2 - I2_true_value);
		e_I = fabs(I_ - I_true_value);
		printf("I1, I2, Iが５桁以上正しくなるn1,n2は、n1 = %d, n2 = %d\n",n1,n2);
		printf("I_1 = %.10e\n",I_1);
		printf("I_true_value = %.10e\n",I1_true_value);
		printf("error(I1) = %.10e\n",e_I1);
		printf("I_2 = %.10e\n",I_2);
		printf("I2_true_value = %.10e\n",I2_true_value);
		printf("error(I2) = %.10e\n",e_I2);
		printf("I = %.10e\n",I_);
		printf("I_true_value = %.10e\n",I_true_value);
		printf("error(I) = %.10e\n",e_I);
	}else printf("error\n");
	return 0;
}
