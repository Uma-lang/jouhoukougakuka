#include<stdio.h>
#include<math.h>
double f(double x,double z){
	if(x == sqrt(1 - z * z)){
		return 0.0;
	}else{
		double y = sqrt(1 - z * z - x * x);
	return y;
	}
}
double intx(double z, int nx){
	int i;
	double a = 0.0;
	double b = sqrt(1 - z * z);
	double h = (b - a) / 2.0 / nx;
	double sum_2i0 = 0.0, sum_2i1 = 0.0;
	for(i = 0; i < nx * 2; i ++){
		double x = a + i * h;
		if(i % 2 == 0){
			sum_2i0 += f(x,z);
		}else{
			sum_2i1 += f(x,z);
		}
	}
	double y = h / 3.0 * (f(a,z) + 2.0 * sum_2i0 + 4.0 * sum_2i1 + f(b,z));
	return y;
}	
int main(){
	int i;
	double a = 0.0;
	double b = 1.0;
	int nz = 1001;
	int nx = 1000;
	double h = (b - a) / 2.0 / nz;
	double sum_2i0 = 0.0,sum_2i1 = 0.0;
	for(i = 0; i < nz * 2; i++){
		double z = a + i * h;
		if(i % 2 == 0){
			sum_2i0 += intx(z,nx);
		}else{
			sum_2i1 += intx(z,nx);
		}
	}
	double y = h / 3.0 * (intx(a,nx) + 2.0 * sum_2i0 + 4.0 * sum_2i1 + intx(b,nx));
	double my_ans = 8.0 * y;
	double true_ans = 4.0 * M_PI /3.0;
	double error = my_ans - true_ans;
	printf("nx = %d, nz = %d\n",nx,nz);
	printf("my_ans = %.10e\n",my_ans);
	printf("truw_ans = %.10e\n",true_ans);
	printf("error = %.10e\n",error);
	return 0;
}
