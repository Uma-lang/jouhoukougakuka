#include <stdio.h>
#include <math.h>

double f1(double x, double z) {
    double y;
    if (x == sqrt(1 - z * z)) {
        y = 0.0;
    } else {
        y = sqrt(1 - z * z - x * x);
    }
    return y;
}

double intx(double a, double b, int n, double f(double, double)) {
    int i;
    double h = (b - a) / 2.0 / n;
    double sum_2i0 = 0.0, sum_2i1 = 0.0;
    for (i = 0; i < n * 2; i++) {
        double xz = a + i * h;
        if (i % 2 == 0) {
            sum_2i0 += f(xz, 0.0); // Assuming z = 0.0
        } else {
            sum_2i1 += f(xz, 0.0);
        }
    }
    double y = h / 3.0 * (f(a, 0.0) + 2.0 * sum_2i0 + 4.0 * sum_2i1 + f(b, 0.0));
    return y;
}

int main() {
    double a = 0.0;
    double b = 1.0;
    int nz = 1000;
    int nx = 1000;

    double y1 = intx(a, b, nx, f1);
    double my_ans = 8.0 * y1;
    double true_ans = 4.0 * M_PI / 3.0;
    double error = fabs(my_ans - true_ans);

    printf("nx = %d, nz = %d\n", nx, nz);
    printf("my_ans = %.10e\n", my_ans);
    printf("true_ans = %.10e\n", true_ans);
    printf("error = %.10e\n", error);

    return 0;
}

