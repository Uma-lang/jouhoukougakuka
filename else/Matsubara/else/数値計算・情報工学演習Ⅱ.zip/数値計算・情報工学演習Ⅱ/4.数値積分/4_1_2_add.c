#include<stdio.h>
#include<math.h>
double f1(double x){
	return 1.0 / (x * x + 1.0);
}
double f2(double x){
	 return sqrt((x - 2) * (4 - x)) / 2.0;
}
double I(double a, double b, int n, double f(double)){
	int i;
	double h = (b - a) / 3.0 / n;
	double sum_3i0=0.0, sum_3i1=0.0, sum_3i2=0.0;
	for(i = 3; i < 3 * n; i+=3){
		double x = a + i * h;
		sum_3i0 += f(x);
	}
	for(i = 1; i < 3 * n; i+=3){
		double x = a + i * h;
		sum_3i1 += f(x);
	}
	for(i = 2; i < 3 * n; i+=3){
		double x = a + i * h;
		sum_3i2 += f(x);
	}
	return 3.0 * h / 8.0 * (f(a) + 2.0 * sum_3i0 + 3.0 * sum_3i1 + 3.0 * sum_3i2 + f(b));
}
int main(){
	double a1 = 0.0, b1 = 1.0;
	double a2 = 2.0, b2 = 4.0;
	int n1 = 136200, n2 = 500;
	double I1_true_value = M_PI / 4.0, I2_true_value = M_PI / 4.0, I_true_value = M_PI / 2.0;
	double I_1 = I(a1,b1,n1,f1);
	double I_2 = I(a2,b2,n2,f2);
	double I_ = I_1 + I_2;
	double e_I1 = I_1 - I1_true_value;
	double e_I2 = I_2 - I2_true_value;
	double e_I = I_ - I_true_value;
	printf("n1 = %d, n2 = %d\n",n1,n2);
	printf("I_1 = %.10e\n",I_1);
	printf("I_true_value = %.10e\n",I1_true_value);
	printf("error(I1) = %.10e\n",e_I1);
	printf("I_2 = %.10e\n",I_2);
	printf("I2_true_value = %.10e\n",I2_true_value);
	printf("error(I2) = %.10e\n",e_I2);
	printf("I = %.10e\n",I_);
	printf("I_true_value = %.10e\n",I_true_value);
	printf("error(I) = %.10e\n",e_I);
	return 0;
}
